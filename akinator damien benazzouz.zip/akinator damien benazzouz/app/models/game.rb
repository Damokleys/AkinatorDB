class Game < ApplicationRecord
end
